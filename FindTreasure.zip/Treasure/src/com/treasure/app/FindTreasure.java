package com.treasure.app;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FindTreasure {
	
	  public static final int ModeLookingForTag = 0;
	  public static final int ModeLookingForValue = 1;
	  public static final int ModeLookingForDirection = 2;
	  
	  public static final int ModeLookingForNumber = 3;
	  public static final int ModeReadingNumber = 4;
	  public static final int ModeLookingForUnits = 5;
	  public static final int ModeReadingUnits = 6;
	  
	  public static class Vector{
		  public float x = 0;
		  public float y = 0;
		  
		  public void Add(Vector v){
			  this.x += v.x;
			  this.y += v.y;
			  
		  }
	  }
	  public static void main(String[] args){		  
		  Vector coord = new Vector();
		  
		  //The try-with-resources statement ensures that each resource is closed at the end of the statement.
		  try (BufferedReader reader = new BufferedReader(new FileReader("c:/treasure/map.txt"))) {
		      String line = null;
		      while ((line = reader.readLine()) != null) {
		          System.out.println(line);
		          
		          Vector delta = parseLine(line);
		          coord.Add(delta);
		      }
		      
		      String yDir = "North";
		      String xDir = "East";
		      if(coord.y < 0){
		    	  yDir = "South";
		      }
		      
		      if(coord.x < 0){
		    	  xDir = "West";
		      }
		      System.out.println(String.format("%f miles to the %s, %f miles to the %s", Math.abs(coord.y), yDir, Math.abs(coord.x), xDir));
		      
		  } catch (IOException e) {
		      System.err.format("IOException: %s%n", e);		      
		  }
	  }
	  
	  public static Vector parseLine(String str){
		  Vector ret = new Vector();
		  int pos = 0;
		  int mode = ModeLookingForTag;
		  String tag = "";
		  int comma = 0;
		  int duration = 0;
		  String direction = "";
		  
		  while(pos < str.length()){
			  switch(mode){
			  		case ModeLookingForTag:
			  			comma = str.indexOf(",");
			  			if(comma < 0){
			  				// Parsing error
			  			}
			  			// Tag is always at the start of the string!
			  			tag = str.substring(0, comma);
			  			pos = comma+1;
			  			mode = ModeLookingForValue;
				    break;
			  		case ModeLookingForValue:
			  			String valStr =str.substring(pos, str.length()); 
			  			comma = valStr.indexOf(",");
			  			if(comma < 0){
			  				// Parsing error
			  			}
			  			String val = valStr.substring(0, comma);
			  			duration = parseValue(val);
			  			pos += comma+1;
			  			
			  			mode = ModeLookingForDirection;
			  			
			  		break;
			  		case ModeLookingForDirection:
			  			direction = str.substring(pos, str.length()).trim();
			  			pos = str.length();
			  		break;
			  }
		  }
		  
		  ret = convertToVector(duration, direction, getSpeed(tag));
		  
		  return ret;
	  }
	  
	  public static float getSpeed(String tag){
		  tag = tag.toLowerCase();
		  float ret = 0;
		  if(tag.equals("walk")){
			  ret = 3.0f;
		  }else if(tag.equals("run")){
			  ret = 6.0f;
		  }else if(tag.equals("horse trot")){
			  ret = 4.0f;
		  }else if(tag.equals("horse gallop")){
			  ret = 15.0f;
		  }else if(tag.equals("elephant ride")){
			  ret = 6.0f;
		  }
		  // convert mph to mpm
		  return ret / 60.0f;
	  }

	  public static int parseValue(String value){
		  String buffer = "";
		  int pos = 0;
		  int ret = 0;
		  int tmpvalue = 0;
		  int mode = ModeLookingForNumber;
		  value = value.toLowerCase();
		  
		  while(pos < value.length()){
			  char c = value.charAt(pos);
			  
			  switch(mode){
			  case ModeLookingForNumber:
				  if(c >= '0' && c <= '9'){
					  // found a digit, start reading
					  mode = ModeReadingNumber;
					  tmpvalue = 0;
					  buffer = "";
				  }else{
					  pos++;
				  }
				  break;
			  case ModeReadingNumber:
				  if(c >= '0' && c <= '9'){
					  // it's a digit, append
					  buffer += String.valueOf(c);
					  pos++;
				  }else{
					  // the number ended
					  tmpvalue = Integer.parseInt(buffer);
					  mode = ModeLookingForUnits;
				  }
				  
				  break;
			  case ModeLookingForUnits:
				  if(c >= 'a' && c <= 'z'){
					  // found a letter, start reading
					  mode = ModeReadingUnits;
					  buffer = "";
				  }else{
					  pos++;
				  }
				  break;
			  case ModeReadingUnits:
				  boolean isLetter = false;
				  if(c >= 'a' && c <= 'z'){
					  // it's a letter, append
					  buffer += String.valueOf(c);
					  pos++;
					  isLetter = true;
				  }
				  
				  if(!isLetter || pos >= value.length())
				  {
					  // the word ended
					  if(buffer.equals("hour") || buffer.equals("hours")){
						  ret += tmpvalue * 60;
					  }else if(buffer.equals("min") || buffer.equals("mins")){
						  ret += tmpvalue;
					  }
					  // check if there is another number
					  mode = ModeLookingForNumber;
				  }
				  break;
			  }
		  }		  
		  return ret;
	  }
	  
	  public static Vector convertToVector(int distance, String dir, float speed){
		  Vector ret = new Vector();
		  float dist = (float)distance * speed;
		  float distDiag = dist * (float)Math.sin(0.5);
		  
		  dir = dir.toLowerCase();
		  
		  if(dir.equals("n")){
			  ret.y = dist;
		  }else if(dir.equals("s")){
			  ret.y = -dist;
		  }else if(dir.equals("w")){
			  ret.x = -dist;
		  }else if(dir.equals("e")){
			  ret.x = dist;			  
		  }else if(dir.equals("nw")){
			  ret.x = -distDiag;
			  ret.y = distDiag;
		  }else if(dir.equals("ne")){
			  ret.x = distDiag;
			  ret.y = distDiag;
		  }else if(dir.equals("sw")){
			  ret.x = -distDiag;
			  ret.y = -distDiag;
		  }else if(dir.equals("se")){
			  ret.x = distDiag;
			  ret.y = -distDiag;			  
		  }		  
		  return ret;
	  }	  
}